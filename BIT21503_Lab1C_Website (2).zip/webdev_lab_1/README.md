# BIT21503 Lab 1(C) Website

A simple HTML and CSS website created for the Introduction to Git and GitHub lab.

## How to use
1. Open `index.html` in a browser to preview the website.
2. Open this folder in Visual Studio Code.
3. Initialize a Git repository, commit the file, and publish it to a public GitHub repository.
4. Enable GitHub Pages from the `main` branch and `/ (root)` folder.

Replace any personal details if you decide to add them. Capture your own screenshots of the actual GitHub repository and published website for the lab submission.
